# Handoff spec: N-seed backbone for "grokking builds a reusable modular-sum module"

For the coding agent (opencode). Read this whole file before writing code. Work in the
existing `consolidation_reuse` project. Put everything in a NEW self-contained folder
`consolidation_reuse/nseed_backbone/`. Do not edit any existing file. Import from the parent
folder with `sys.path.insert(0, parent)`: `core.make_model`, `core.model_config`,
`core.symmetry_split`, `model_phase3.ContextualTransformer`.

Rules for you:
- CPU only, Windows, PowerShell commands. Everything must be resumable and save incrementally.
- Report only what actually ran. Never invent numbers. A syntax check is not a run.
- If a test fails, fix the cause. Do not weaken the test.
- Do not tune hyperparameters. They are fixed below.

## 0. Scientific question (so you know what matters)

Claim under test: a model that has *grokked* modular addition (not merely memorized it) is a
much better initialization for related tasks, including tasks that are not functions of a+b.
We need this over many independent seeds, with a weight-norm control, and with a measurement
of which part of the network carries the reusable structure.

Already known (do not redo): seeds 3 and 4 at 40% coverage grok at ~7.5k and ~5.5k steps. At a
fixed 2,000-step budget, grokked sources reach about 63-84% on affine, and pre-grok sources and
scratch reach 1-3%. This spec adds independent seeds and controls.

## 1. Fixed settings

- p=59, n_contexts=4, d_model=128, n_heads=4, d_mlp=512 (use `core.make_model`).
- Optimizer: AdamW lr=0.001, weight_decay=1.0, betas=(0.9, 0.98). Full-batch. Fresh optimizer
  for every stage and every transfer.
- Coverage 0.4: `count = int(0.4*p*p) = 1392` training pairs, the SAME pair mask in all four
  contexts (train examples = 4 x 1392 = 5568).
- Mask for seed S: `g = torch.Generator().manual_seed(100000+S)`; `selected = torch.randperm(p*p, generator=g)[:count]`.
  Model init: `torch.manual_seed(S)` (also seed `random` and `numpy`) immediately before `make_model`.
- Splits: `core.symmetry_split(mask, p, 1701)`. Use `strata['train']`, `strata['dev']`.
  `strata['audit']` is never read during the run. It is read only by `analyze.py --final` (see section 6).
- Input format: tokens `[p+context, a, b, p+n_contexts]` (same as `core.build_data`).
  Examples ordered context-major over `cartesian_prod(arange(p), arange(p))`.
- Metrics each evaluation: train accuracy; clean-dev accuracy per context; mean and worst
  context. Dev accuracy is computed only on `strata['dev']` ids.
- `torch.set_num_threads(T)` where T is set by the launcher (section 5).
  `torch.use_deterministic_algorithms(True)`.

## 2. Tasks (labels, per example with context c)

- `source`: y = (a+b) mod p, identical in all contexts.
- `affine`: y = (a + (c+1)*b) mod p. Contexts 1-3 are not functions of a+b.
- `scaled`: y = ((c+1)*(a+b)) mod p.
- `input_perm`: y = (s(a)+s(b)) mod p, where s is a fixed random permutation of 0..p-1
  (`torch.randperm(p, generator=Generator().manual_seed(555))`), same in all contexts. This
  relabels INPUTS only. It is used in phase 2.

## 3. Phase 1 per seed: `run_seed.py --seed S --out runs_nseed/seed_S`

**3a. Source training.** Train `source` from scratch. Evaluate every 250 steps.
- Save a model-only checkpoint (`state_dict` + step + metrics row, no optimizer) every 500 steps
  to `ckpts/step_XXXXXXX.pt`. Save a full resumable state (`latest.pt`, atomic write) every 500
  steps, including model, optimizer, RNG state (python, numpy, torch), and the metrics rows.
- Success: train acc >= 0.99 AND worst-context clean-dev >= 0.90 for 3 consecutive evaluations.
  On success, save `ckpts/grokked.pt` (the model at that evaluation) and stop the source.
- Cap: 20,000 source steps. If no success by the cap, save `ckpts/late_memorized.pt` and mark
  the seed `nongrok`. Nongrok seeds are valuable age-matched controls, so keep them.
- Record the global parameter L2 norm and per-module L2 norms at every saved checkpoint.

**3b. Stage selection (no peeking at transfer results).** From the saved evaluation rows, label
checkpoints:
- `memorized`: the saved checkpoint at or after the first step with train >= 0.99, with
  worst-context clean-dev < 0.03, nearest to 40% of the grok step.
- `transition`: the saved checkpoint whose mean clean-dev is closest to 0.5, within [0.25, 0.75].
  If none, mark `transition` missing.
- `grokked`: `ckpts/grokked.pt`.
- `late` (tier C only): grok step + 2000, trained by continuing the source.

**3c. Transfers.** Each transfer: load a stage checkpoint, fresh AdamW, train 2,000 steps on the
target task over the same `strata['train']` ids and masks, evaluate clean-dev every 100 steps.
Priority tiers, in this order (so an interrupted night still produces usable data):
- Tier A: `affine` from {memorized, transition, grokked}; plus `norm_control`:
  `affine` from the memorized checkpoint with ALL parameters multiplied by one scalar so that
  its global parameter L2 norm equals the grokked checkpoint's.
- Tier B: `scaled` from {memorized, transition, grokked, norm_control}.
- Tier C: `late` stage on `affine`.
- Scratch baselines are NOT per seed. Run `scratch_affine` and `scratch_scaled` once each for
  init seeds 9001, 9002, 9003 in a separate `run_scratch.py`, using seed 3's mask logic.
- For a `nongrok` seed, run `affine` from `late_memorized` only.

**3d. Embedding Fourier metrics** (offline, no training; `fourier_metrics.py`). For every saved
checkpoint of a seed, take the numeric token embedding E = `token_embed.weight[:p]` (shape p x d).
Compute the DFT over the token axis: F = fft(E, dim=0). For k=1..(p-1)//2, energy_k =
|F_k|^2 + |F_{p-k}|^2 summed over the d dimension. Report:
- `top5_share` = sum of the 5 largest energy_k / sum of all energy_k.
- `freq_participation` = (sum energy_k)^2 / sum(energy_k^2).
- `nonconst_share` = energy over k>=1 / total energy including k=0.
Write one CSV row per (seed, step).

## 4. Phase 2 (run only after the Gate 1 decision, section 7): `run_freeze.py`

On the `grokked` checkpoint of each seed that passed Gate 1, 2,000-step transfers with only a
subset of parameters trainable (all others frozen at source values):
- `train_all` (reference), `freeze_numeric_embed` (train everything except
  `token_embed.weight[:p]`), `embed_only` (train only `token_embed.weight[:p]` and the context
  rows `token_embed.weight[p:p+n]`), `mlp_unembed_only` (train only `mlp_in`, `mlp_out`, `unembed`
  and the context rows).
- Targets: `affine` and `input_perm`.
- Prediction to test: for `affine` (outputs changed, inputs same) freezing the numeric embeddings
  should hurt little. For `input_perm` (inputs relabeled) the reverse should hold: `embed_only`
  should recover much more than `mlp_unembed_only`. State the result per seed, not just means.

## 5. Launcher: `run_batch.py` and benchmark

- First write `benchmark.py`. It measures steps/second of full-batch source training for 200
  steps at thread counts 1, 2, 4 for one process, then with 2 and 4 concurrent processes. It
  writes `benchmark.json` and prints a recommended (processes, threads_per_process) that
  maximizes total steps/second without exceeding physical cores. Print the machine's core count
  and RAM.
- `run_batch.py --seeds 5 6 7 ... --procs P --threads T [--tiers A B C]` runs seeds through a
  queue using `multiprocessing` with the `spawn` start method. `--tiers` defaults to `A B C`;
  the source is always trained. One seed runs fully, tiers in priority order, in one worker.
  The first overnight run uses `--tiers A` on seeds 5 6 7 only (Gate 1). A per-seed lock file prevents two workers from taking the same seed. A killed
  batch resumes with `--resume` and skips finished jobs. Ctrl+C saves the current step and exits.
- Log seconds per step into the metrics CSV.

## 6. Outputs and analysis

- `runs_nseed/seed_S/metrics.csv` (all source and transfer evaluation rows, with a `stage`,
  `task`, `init` column), `runs_nseed/seed_S/summary.json`, `runs_nseed/fourier_metrics.csv`.
- `analyze.py` writes `runs_nseed/summary.csv`: one row per (seed, task, init) with final-dev
  mean accuracy, worst-context, steps to reach 30% dev (or blank), the stage's clean accuracy,
  global norm, `top5_share`, `freq_participation`.
- `analyze.py --gates` prints the verdict for Gate 1 and Gate 2 (section 7) from `summary.csv`,
  with the exact numbers used. It never reads the audit split.
- `analyze.py --final` also reads `strata['audit']` ONCE per finished transfer's last
  checkpoint and writes `audit_final.csv`. Decisions in section 7 use dev numbers only.

## 7. Pre-registered gates (decide before seeing results)

- **Gate 1** (after 3 new seeds finish Tier A): continue if the `grokked` affine final-dev mean is
  >= 0.30 in at least 2 of 3 seeds AND the `memorized` affine final-dev is <= 0.05 in those seeds.
  If it fails, stop and send `summary.csv`. Do not start more seeds.
- **Gate 2** (norm control): if `norm_control` affine reaches >= 50% of the `grokked` affine
  accuracy in the same seed, the weight-norm confound explains much of the effect. Report it and
  stop for review before phase 2.
- **Gate 3** (after 8 or more finished seeds): report the across-seed relation between transfer
  accuracy and (stage clean accuracy, global norm, `top5_share`). Do not run more seeds unless it
  is informative.

## 8. Acceptance tests (`test_nseed.py`, `python -m unittest -v test_nseed`) before any long run

1. Mask: identical across contexts; exactly 1392 pairs; `dev` nonempty; no dev pair or its
   transpose appears in train in any context.
2. Labels: source, affine, scaled, input_perm recomputed independently in the test from (a, b, c)
   and compared to the generated labels.
3. Evaluation: dev accuracy from the run's function equals a plain loop reimplementation on a
   small random model.
4. Resume: train 60 steps uninterrupted vs 30 steps, save, resume, 30 more. Model tensors and
   optimizer state must match exactly.
5. Norm control: after rescaling, the global parameter norm matches the target within 1e-6
   relative, and the model's logits are scaled consistently (just check the norm).
6. Fourier: for a synthetic embedding E[a] = cos(2*pi*7*a/p) in one column, `top5_share` is
   about 1.0 and the peak is at k=7.
7. Smoke: a 300-step source run with a deliberately small batch cap writes valid CSVs.

Paste the actual test output in your report. List what was NOT tested, including Windows signal
handling.

## 9. What to send back each session

`summary.csv`, `runs_nseed/fourier_metrics.csv`, `benchmark.json`, the stdout tail, and the list of
seeds with their status (`grokked`, `nongrok`, `unfinished`).
