You are implementing an experiment harness in this project (`consolidation_reuse`). Your job
right now is BUILD, TEST, and BENCHMARK only. Do not start any long run.

1. Read `nseed_backbone/SPEC.md` completely, then `reference/README.md`. Read `core.py` and
   `model_phase3.py` so you reuse `core.make_model`, `core.symmetry_split`, and the model class.
   Do not modify `core.py`, `model_phase3.py`, or anything in `reference/`.
2. Create these files inside `nseed_backbone/`: `common.py` (data, labels, evaluation,
   checkpointing, resume), `run_seed.py`, `run_scratch.py`, `run_batch.py`, `benchmark.py`,
   `fourier_metrics.py`, `analyze.py`, `test_nseed.py`. `run_freeze.py` (spec section 4) may be
   written but must not be run.
3. Follow the spec literally. Fixed hyperparameters are not yours to change. If something in the
   spec is ambiguous or seems wrong, write your question in `nseed_backbone/QUESTIONS.md` and
   take the most literal reading. Do not silently deviate.
4. Run `python -m unittest -v nseed_backbone.test_nseed` from the project root (or the working
   equivalent) and fix failures at their cause. Do not weaken tests.
5. Run `python nseed_backbone\benchmark.py`.
6. Finish by writing `nseed_backbone/REPORT_1.md` containing: the exact test command and its
   full output; the contents of `benchmark.json`; the recommended processes and threads; the
   list of files you created; anything not tested (for example Windows Ctrl+C handling); and
   open questions. Report only what actually ran.

Then stop and wait. Do not run `run_batch.py`.
