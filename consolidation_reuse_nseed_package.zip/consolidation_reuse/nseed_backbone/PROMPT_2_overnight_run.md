Precondition: `nseed_backbone/REPORT_1.md` exists, all tests passed, and the user has confirmed
the processes and threads to use. If any precondition is false, stop and say so.

Run the Gate 1 batch exactly as follows, from the project root:

1. `python nseed_backbone\run_batch.py --seeds 5 6 7 --procs <P> --threads <T> --tiers A`
   Use the recommended <P> and <T> from `benchmark.json`. Run it in the background and keep the
   log at `runs_nseed\batch.log`. If it is interrupted, restart with `--resume`.
2. When it finishes, run `python nseed_backbone\run_scratch.py` (scratch baselines for init
   seeds 9001, 9002, 9003 on `affine` and `scaled`).
3. Run `python nseed_backbone\fourier_metrics.py`, then `python nseed_backbone\analyze.py`, then
   `python nseed_backbone\analyze.py --gates`.
4. Write `nseed_backbone\REPORT_2.md`: seed statuses (grokked / nongrok / unfinished), the step at
   which each seed grokked, the summary table, the Gate 1 and Gate 2 verdicts exactly as printed
   by `analyze.py --gates`, and anything that looked wrong or surprising. Report only what ran.

Do NOT start more seeds, do NOT run Tier B or C, do NOT run `run_freeze.py`, do NOT run
`analyze.py --final`, and do NOT change any setting based on the results. Stop after writing the
report, even if a gate fails.
