# Setup on the new Windows machine (PowerShell)

1. Unzip and enter the folder
   Expand-Archive .\consolidation_reuse_nseed_package.zip -DestinationPath .
   cd .\consolidation_reuse

2. Check Python (3.10 or newer; 3.12 is fine)
   python --version

3. Create and activate a virtual environment
   python -m venv .venv
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1

4. Install dependencies (CPU-only PyTorch)
   python -m pip install --upgrade pip
   pip install numpy pandas
   pip install torch --index-url https://download.pytorch.org/whl/cpu

5. Verify the environment (about 1 minute). Expected last line: OK
   python check_env.py
   - The split sizes line must read: {'train': 1392, 'dev': 624, 'audit': 619, 'exposed': 846}
   - If it says SPLIT MISMATCH, stop and send the full output.

6. Machine facts (send these with the check_env output)
   Get-CimInstance Win32_Processor | Select-Object NumberOfCores,NumberOfLogicalProcessors
   (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB

7. Start your coding assistant from this folder (`consolidation_reuse`) and paste
   nseed_backbone\PROMPT_1_build_and_test.md. When it finishes, send me
   nseed_backbone\REPORT_1.md and nseed_backbone\benchmark.json.

8. Only after I confirm the processes/threads: paste nseed_backbone\PROMPT_2_overnight_run.md
   before you leave. Do not close the terminal or let the machine sleep while it runs
   (Settings > System > Power > Screen and sleep > Never, for the run).

What to send back after the overnight run
   nseed_backbone\REPORT_2.md
   runs_nseed\summary.csv
   runs_nseed\fourier_metrics.csv
   runs_nseed\batch.log (last 100 lines)
