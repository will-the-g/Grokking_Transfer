# Reference results (read-only, from the previous machine)

These are the results the new work builds on. Do not modify them. Use them to sanity-check
new numbers: new seeds should look qualitatively like seeds 3 and 4, or the difference must be
explained.

- seed3_/seed4_replication_metrics.csv: 40%-coverage shared-addition sources (grok at ~7.5k / ~5.5k
  steps) and their 2,000-step scaled / four-relabeling transfers plus scratch baselines.
- pre_grok_controls.csv: memorized (pre-grok) sources, same transfers: ~1%.
- affine_boundary_metrics.csv: target y=a+(c+1)b. post_grok vs pre_grok vs scratch.
- affine_early_path / affine_freeze / affine_attention_only: which parameters were trainable.
  Note: the variant definitions are in the old scripts, which are NOT included here.
- control_scaled_transfer / selector_transfer: grokked copy-a and a/b-selector sources do not
  transfer to scaled.
- sum_remapping_metrics.csv: arbitrary output relabelings from a grokked addition source.
- sharing_metrics.csv: local gradient-cosine screen. Same-context and cross-context values are
  identical, which suggests the shared-rule model ignores the context token.
- ladder_clean_trajectory.csv: 30%-coverage shifted/scaled ladder on symmetry-clean pairs.
- seed3_/seed4_experiment.json: masks and settings of those two runs.
- RESEARCH_WORKING_GUIDE.md: collaboration and scientific standards agreed earlier.
