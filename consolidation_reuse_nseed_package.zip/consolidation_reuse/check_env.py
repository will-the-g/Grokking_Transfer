"""Environment check. Run from the consolidation_reuse folder: python check_env.py

Verifies that torch/numpy import, that core.py and model_phase3.py load, that the
symmetry-clean split for the seed-5, 40%-coverage mask has the expected sizes, and
reports full-batch training speed. It trains nothing that is saved.
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np
import torch

from core import make_model, symmetry_split

print('python', sys.version.split()[0], '| torch', torch.__version__, '| numpy', np.__version__)
print('cpu threads torch sees:', torch.get_num_threads())

p, n = 59, 4
g = torch.Generator().manual_seed(100005)
selected = torch.randperm(p * p, generator=g)[:int(.4 * p * p)]
mask = torch.zeros((n, p * p), dtype=torch.bool)
mask[:, selected] = True
strata, _ = symmetry_split(mask, p, 1701)
sizes = {k: len(v) for k, v in strata.items()}
print('split sizes (seed 5, 40% coverage):', sizes)
expected = {'train': 1392, 'dev': 624, 'audit': 619, 'exposed': 846}
print('split sizes match expected:', sizes == expected)

model = make_model(dict(p=59, n_contexts=4, d_model=128, n_heads=4, d_mlp=512))
x = torch.randint(0, 59, (5568, 4))
x[:, 0] = 59 + torch.randint(0, 4, (5568,))
x[:, 3] = 63
y = torch.randint(0, 59, (5568,))
opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1., betas=(.9, .98))
for threads in (1, 2, 4):
    torch.set_num_threads(threads)
    start = time.time()
    for _ in range(20):
        opt.zero_grad()
        torch.nn.functional.cross_entropy(model(x), y).backward()
        opt.step()
    print(f'full-batch steps/s with {threads} thread(s), 1 process: {20 / (time.time() - start):.2f}')
print('OK' if sizes == expected else 'SPLIT MISMATCH - do not proceed')
