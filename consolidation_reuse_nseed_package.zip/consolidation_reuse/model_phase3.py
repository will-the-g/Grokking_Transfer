import torch
from torch import nn


class ContextualTransformer(nn.Module):
    """One-block causal transformer with an explicit context token."""

    def __init__(self, p=59, n_contexts=4, d_model=128, n_heads=4, d_mlp=512):
        super().__init__()
        self.p = p
        self.n_contexts = n_contexts
        self.context_offset = p
        self.equals_token = p + n_contexts
        self.vocab = p + n_contexts + 1
        self.token_embed = nn.Embedding(self.vocab, d_model)
        self.pos_embed = nn.Parameter(torch.empty(4, d_model))
        self.attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True)
        self.mlp_in = nn.Linear(d_model, d_mlp)
        self.mlp_out = nn.Linear(d_mlp, d_model)
        self.unembed = nn.Linear(d_model, p, bias=False)
        self.register_buffer(
            "causal_mask",
            torch.triu(torch.ones(4, 4, dtype=torch.bool), diagonal=1),
        )
        nn.init.normal_(self.pos_embed, std=0.02)

    def forward(self, tokens, return_cache=False, ablate_directions=None,
                ablate_mean=None):
        x0 = self.token_embed(tokens) + self.pos_embed.unsqueeze(0)
        attn_out, attn_weights = self.attn(
            x0, x0, x0, attn_mask=self.causal_mask,
            need_weights=return_cache, average_attn_weights=False,
        )
        x1 = x0 + attn_out
        hidden = torch.relu(self.mlp_in(x1))

        if ablate_directions is not None:
            directions = ablate_directions.to(hidden.device, hidden.dtype)
            if directions.ndim == 1:
                directions = directions.unsqueeze(0)
            mean = torch.zeros(hidden.shape[-1], device=hidden.device,
                               dtype=hidden.dtype)
            if ablate_mean is not None:
                mean = ablate_mean.to(hidden.device, hidden.dtype)
            last = hidden[:, -1, :]
            centered = last - mean
            projection = (centered @ directions.T) @ directions
            hidden = hidden.clone()
            hidden[:, -1, :] = last - projection

        x2 = x1 + self.mlp_out(hidden)
        logits = self.unembed(x2[:, -1, :])
        if return_cache:
            return logits, {
                "embed": x0.detach(),
                "attn": attn_out.detach(),
                "post_attn": x1.detach(),
                "mlp_hidden": hidden.detach(),
                "resid": x2.detach(),
                "attn_weights": attn_weights.detach(),
            }
        return logits


def condition_task_spec(condition, n_contexts, cfg):
    """Return coefficients and output shifts for one ladder condition.

    Every condition has the form
        y = alpha_c * a + beta_c * b + shift_c (mod p).
    """
    if condition == "shared":
        coefficients = [(1, 1)] * n_contexts
        shifts = [0] * n_contexts
    elif condition == "shifted":
        coefficients = [(1, 1)] * n_contexts
        shifts = list(map(int, cfg["shifted_offsets"]))
    elif condition == "scaled":
        multipliers = list(map(int, cfg["scaled_multipliers"]))
        coefficients = [(value, value) for value in multipliers]
        shifts = [0] * n_contexts
    elif condition in ("related", "affine"):
        coefficients = [tuple(map(int, pair))
                        for pair in cfg["related_coefficients"]]
        shifts = [0] * n_contexts
    else:
        raise ValueError(f"Unknown condition: {condition}")

    if len(coefficients) != n_contexts or len(shifts) != n_contexts:
        raise ValueError(
            f"Condition {condition!r} needs one rule per context "
            f"(expected {n_contexts})")
    return {
        "condition": condition,
        "coefficients": coefficients,
        "shifts": shifts,
    }


def condition_coefficients(condition, n_contexts, related_coefficients):
    """Backward-compatible helper used by older notebooks."""
    cfg = {
        "related_coefficients": related_coefficients,
        "shifted_offsets": [0] * n_contexts,
        "scaled_multipliers": list(range(1, n_contexts + 1)),
    }
    return condition_task_spec(condition, n_contexts, cfg)["coefficients"]


def make_contextual_inputs(p, coefficients, device, shifts=None):
    """Order is context-major, then the standard cartesian-product order."""
    pairs = torch.cartesian_prod(torch.arange(p), torch.arange(p)).to(device)
    a, b = pairs[:, 0], pairs[:, 1]
    xs, ys, contexts, pair_ids = [], [], [], []
    equals_token = p + len(coefficients)
    if shifts is None:
        shifts = [0] * len(coefficients)
    if len(shifts) != len(coefficients):
        raise ValueError("shifts must have one value per context")
    for context, ((alpha, beta), shift) in enumerate(zip(coefficients, shifts)):
        context_column = torch.full_like(a, p + context)
        equals_column = torch.full_like(a, equals_token)
        xs.append(torch.stack((context_column, a, b, equals_column), dim=1))
        ys.append((alpha * a + beta * b + shift) % p)
        contexts.append(torch.full_like(a, context))
        pair_ids.append(torch.arange(p * p, device=device))
    return (torch.cat(xs), torch.cat(ys), torch.cat(contexts),
            torch.cat(pair_ids))
